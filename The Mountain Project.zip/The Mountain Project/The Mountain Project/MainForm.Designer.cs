﻿
namespace The_Mountain_Project
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bunifuImageButton2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Gora1 = new System.Windows.Forms.Panel();
            this.textGora1Alp = new System.Windows.Forms.TextBox();
            this.textGora1Kor = new System.Windows.Forms.TextBox();
            this.Gora1text = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textGora2Kor = new System.Windows.Forms.TextBox();
            this.textGora2Alp = new System.Windows.Forms.TextBox();
            this.Gora2text = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textGora3Kor = new System.Windows.Forms.TextBox();
            this.textGora3Alp = new System.Windows.Forms.TextBox();
            this.Gora3text = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textGora4Kor = new System.Windows.Forms.TextBox();
            this.textGora4Alp = new System.Windows.Forms.TextBox();
            this.Gora4text = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.textGora5Kor = new System.Windows.Forms.TextBox();
            this.textGora5Alp = new System.Windows.Forms.TextBox();
            this.Gora5text = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.textGora6Kor = new System.Windows.Forms.TextBox();
            this.textGora6Alp = new System.Windows.Forms.TextBox();
            this.Gora6text = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.textGora7Kor = new System.Windows.Forms.TextBox();
            this.textGora7Alp = new System.Windows.Forms.TextBox();
            this.Gora7text = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.textGora8Kor = new System.Windows.Forms.TextBox();
            this.textGora8Alp = new System.Windows.Forms.TextBox();
            this.Gora8text = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.textGora9Kor = new System.Windows.Forms.TextBox();
            this.textGora9Alp = new System.Windows.Forms.TextBox();
            this.Gora9text = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.textGora10Kor = new System.Windows.Forms.TextBox();
            this.textGora10Alp = new System.Windows.Forms.TextBox();
            this.Gora10text = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.bunifuElipse2 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.Gora1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(28)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.bunifuImageButton1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1192, 48);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::The_Mountain_Project.Properties.Resources.THE_MOUNTAIN;
            this.pictureBox1.Location = new System.Drawing.Point(74, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(184, 33);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.bunifuImageButton1.Image = global::The_Mountain_Project.Properties.Resources.fuji;
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(11, 1);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(51, 47);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 0;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
     
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.panel2.Controls.Add(this.panel12);
            this.panel2.Controls.Add(this.bunifuImageButton2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 48);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(68, 542);
            this.panel2.TabIndex = 1;
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.bunifuImageButton2.Image = global::The_Mountain_Project.Properties.Resources.Close;
            this.bunifuImageButton2.ImageActive = null;
            this.bunifuImageButton2.Location = new System.Drawing.Point(12, 496);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Size = new System.Drawing.Size(50, 34);
            this.bunifuImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton2.TabIndex = 0;
            this.bunifuImageButton2.TabStop = false;
            this.bunifuImageButton2.Zoom = 10;
            this.bunifuImageButton2.Click += new System.EventHandler(this.bunifuImageButton2_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(44)))), ((int)(((byte)(53)))));
            this.flowLayoutPanel1.Controls.Add(this.Gora1);
            this.flowLayoutPanel1.Controls.Add(this.panel3);
            this.flowLayoutPanel1.Controls.Add(this.panel4);
            this.flowLayoutPanel1.Controls.Add(this.panel5);
            this.flowLayoutPanel1.Controls.Add(this.panel6);
            this.flowLayoutPanel1.Controls.Add(this.panel10);
            this.flowLayoutPanel1.Controls.Add(this.panel7);
            this.flowLayoutPanel1.Controls.Add(this.panel8);
            this.flowLayoutPanel1.Controls.Add(this.panel9);
            this.flowLayoutPanel1.Controls.Add(this.panel11);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(68, 48);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1011, 542);
            this.flowLayoutPanel1.TabIndex = 2;
            // 
            // Gora1
            // 
            this.Gora1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.Gora1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Gora1.Controls.Add(this.textGora1Alp);
            this.Gora1.Controls.Add(this.textGora1Kor);
            this.Gora1.Controls.Add(this.Gora1text);
            this.Gora1.Controls.Add(this.textBox1);
            this.Gora1.Controls.Add(this.pictureBox2);
            this.Gora1.Location = new System.Drawing.Point(3, 3);
            this.Gora1.Name = "Gora1";
            this.Gora1.Size = new System.Drawing.Size(242, 300);
            this.Gora1.TabIndex = 0;
            // 
            // textGora1Alp
            // 
            this.textGora1Alp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.textGora1Alp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textGora1Alp.Enabled = false;
            this.textGora1Alp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora1Alp.Location = new System.Drawing.Point(3, 270);
            this.textGora1Alp.Multiline = true;
            this.textGora1Alp.Name = "textGora1Alp";
            this.textGora1Alp.Size = new System.Drawing.Size(175, 27);
            this.textGora1Alp.TabIndex = 4;
            // 
            // textGora1Kor
            // 
            this.textGora1Kor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.textGora1Kor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textGora1Kor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textGora1Kor.ForeColor = System.Drawing.Color.Silver;
            this.textGora1Kor.Location = new System.Drawing.Point(169, 4);
            this.textGora1Kor.Multiline = true;
            this.textGora1Kor.Name = "textGora1Kor";
            this.textGora1Kor.ReadOnly = true;
            this.textGora1Kor.Size = new System.Drawing.Size(77, 39);
            this.textGora1Kor.TabIndex = 3;
            // 
            // Gora1text
            // 
            this.Gora1text.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.Gora1text.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Gora1text.Enabled = false;
            this.Gora1text.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Gora1text.Location = new System.Drawing.Point(0, 241);
            this.Gora1text.Multiline = true;
            this.Gora1text.Name = "Gora1text";
            this.Gora1text.Size = new System.Drawing.Size(242, 26);
            this.Gora1text.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(0, 208);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(242, 27);
            this.textBox1.TabIndex = 1;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::The_Mountain_Project.Properties.Resources.Эверест;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(242, 202);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.textGora2Kor);
            this.panel3.Controls.Add(this.textGora2Alp);
            this.panel3.Controls.Add(this.Gora2text);
            this.panel3.Controls.Add(this.textBox5);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Location = new System.Drawing.Point(251, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(242, 300);
            this.panel3.TabIndex = 5;
            // 
            // textGora2Kor
            // 
            this.textGora2Kor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.textGora2Kor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textGora2Kor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora2Kor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textGora2Kor.Location = new System.Drawing.Point(168, 1);
            this.textGora2Kor.Multiline = true;
            this.textGora2Kor.Name = "textGora2Kor";
            this.textGora2Kor.ReadOnly = true;
            this.textGora2Kor.Size = new System.Drawing.Size(74, 39);
            this.textGora2Kor.TabIndex = 3;
            // 
            // textGora2Alp
            // 
            this.textGora2Alp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.textGora2Alp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textGora2Alp.Enabled = false;
            this.textGora2Alp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora2Alp.Location = new System.Drawing.Point(3, 270);
            this.textGora2Alp.Multiline = true;
            this.textGora2Alp.Name = "textGora2Alp";
            this.textGora2Alp.Size = new System.Drawing.Size(175, 27);
            this.textGora2Alp.TabIndex = 4;
            // 
            // Gora2text
            // 
            this.Gora2text.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.Gora2text.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Gora2text.Enabled = false;
            this.Gora2text.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Gora2text.Location = new System.Drawing.Point(0, 241);
            this.Gora2text.Multiline = true;
            this.Gora2text.Name = "Gora2text";
            this.Gora2text.Size = new System.Drawing.Size(242, 26);
            this.Gora2text.TabIndex = 2;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Enabled = false;
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox5.Location = new System.Drawing.Point(0, 208);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(242, 27);
            this.textBox5.TabIndex = 1;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::The_Mountain_Project.Properties.Resources.Чогори;
            this.pictureBox3.Location = new System.Drawing.Point(0, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(242, 202);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.textGora3Kor);
            this.panel4.Controls.Add(this.textGora3Alp);
            this.panel4.Controls.Add(this.Gora3text);
            this.panel4.Controls.Add(this.textBox9);
            this.panel4.Controls.Add(this.pictureBox4);
            this.panel4.Location = new System.Drawing.Point(499, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(242, 300);
            this.panel4.TabIndex = 6;
            // 
            // textGora3Kor
            // 
            this.textGora3Kor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.textGora3Kor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textGora3Kor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora3Kor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textGora3Kor.Location = new System.Drawing.Point(168, 1);
            this.textGora3Kor.Multiline = true;
            this.textGora3Kor.Name = "textGora3Kor";
            this.textGora3Kor.ReadOnly = true;
            this.textGora3Kor.Size = new System.Drawing.Size(74, 39);
            this.textGora3Kor.TabIndex = 3;
            // 
            // textGora3Alp
            // 
            this.textGora3Alp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.textGora3Alp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textGora3Alp.Enabled = false;
            this.textGora3Alp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora3Alp.Location = new System.Drawing.Point(3, 270);
            this.textGora3Alp.Multiline = true;
            this.textGora3Alp.Name = "textGora3Alp";
            this.textGora3Alp.Size = new System.Drawing.Size(175, 27);
            this.textGora3Alp.TabIndex = 4;
            // 
            // Gora3text
            // 
            this.Gora3text.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.Gora3text.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Gora3text.Enabled = false;
            this.Gora3text.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Gora3text.Location = new System.Drawing.Point(0, 241);
            this.Gora3text.Multiline = true;
            this.Gora3text.Name = "Gora3text";
            this.Gora3text.Size = new System.Drawing.Size(242, 26);
            this.Gora3text.TabIndex = 2;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9.Enabled = false;
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox9.Location = new System.Drawing.Point(0, 208);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(242, 27);
            this.textBox9.TabIndex = 1;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::The_Mountain_Project.Properties.Resources.Канченджанка;
            this.pictureBox4.Location = new System.Drawing.Point(0, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(242, 202);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.textGora4Kor);
            this.panel5.Controls.Add(this.textGora4Alp);
            this.panel5.Controls.Add(this.Gora4text);
            this.panel5.Controls.Add(this.textBox13);
            this.panel5.Controls.Add(this.pictureBox5);
            this.panel5.Location = new System.Drawing.Point(747, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(242, 300);
            this.panel5.TabIndex = 7;
            // 
            // textGora4Kor
            // 
            this.textGora4Kor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.textGora4Kor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textGora4Kor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora4Kor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textGora4Kor.Location = new System.Drawing.Point(168, 1);
            this.textGora4Kor.Multiline = true;
            this.textGora4Kor.Name = "textGora4Kor";
            this.textGora4Kor.ReadOnly = true;
            this.textGora4Kor.Size = new System.Drawing.Size(74, 39);
            this.textGora4Kor.TabIndex = 3;
            // 
            // textGora4Alp
            // 
            this.textGora4Alp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.textGora4Alp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textGora4Alp.Enabled = false;
            this.textGora4Alp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora4Alp.Location = new System.Drawing.Point(3, 270);
            this.textGora4Alp.Multiline = true;
            this.textGora4Alp.Name = "textGora4Alp";
            this.textGora4Alp.Size = new System.Drawing.Size(175, 27);
            this.textGora4Alp.TabIndex = 4;
            // 
            // Gora4text
            // 
            this.Gora4text.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.Gora4text.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Gora4text.Enabled = false;
            this.Gora4text.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Gora4text.Location = new System.Drawing.Point(0, 241);
            this.Gora4text.Multiline = true;
            this.Gora4text.Name = "Gora4text";
            this.Gora4text.Size = new System.Drawing.Size(242, 26);
            this.Gora4text.TabIndex = 2;
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox13.Enabled = false;
            this.textBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox13.Location = new System.Drawing.Point(0, 208);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(242, 27);
            this.textBox13.TabIndex = 1;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::The_Mountain_Project.Properties.Resources.Лхоцзе;
            this.pictureBox5.Location = new System.Drawing.Point(0, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(242, 202);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.textGora5Kor);
            this.panel6.Controls.Add(this.textGora5Alp);
            this.panel6.Controls.Add(this.Gora5text);
            this.panel6.Controls.Add(this.textBox17);
            this.panel6.Controls.Add(this.pictureBox6);
            this.panel6.Location = new System.Drawing.Point(3, 309);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(242, 300);
            this.panel6.TabIndex = 8;
            // 
            // textGora5Kor
            // 
            this.textGora5Kor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.textGora5Kor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textGora5Kor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora5Kor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textGora5Kor.Location = new System.Drawing.Point(168, 3);
            this.textGora5Kor.Multiline = true;
            this.textGora5Kor.Name = "textGora5Kor";
            this.textGora5Kor.ReadOnly = true;
            this.textGora5Kor.Size = new System.Drawing.Size(74, 39);
            this.textGora5Kor.TabIndex = 3;
            // 
            // textGora5Alp
            // 
            this.textGora5Alp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.textGora5Alp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textGora5Alp.Enabled = false;
            this.textGora5Alp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora5Alp.Location = new System.Drawing.Point(3, 270);
            this.textGora5Alp.Multiline = true;
            this.textGora5Alp.Name = "textGora5Alp";
            this.textGora5Alp.Size = new System.Drawing.Size(175, 27);
            this.textGora5Alp.TabIndex = 4;
            // 
            // Gora5text
            // 
            this.Gora5text.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.Gora5text.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Gora5text.Enabled = false;
            this.Gora5text.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Gora5text.Location = new System.Drawing.Point(0, 241);
            this.Gora5text.Multiline = true;
            this.Gora5text.Name = "Gora5text";
            this.Gora5text.Size = new System.Drawing.Size(245, 26);
            this.Gora5text.TabIndex = 2;
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.textBox17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox17.Enabled = false;
            this.textBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox17.Location = new System.Drawing.Point(0, 208);
            this.textBox17.Multiline = true;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(245, 27);
            this.textBox17.TabIndex = 1;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::The_Mountain_Project.Properties.Resources.Макалу;
            this.pictureBox6.Location = new System.Drawing.Point(0, 0);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(242, 202);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel10.Controls.Add(this.textGora6Kor);
            this.panel10.Controls.Add(this.textGora6Alp);
            this.panel10.Controls.Add(this.Gora6text);
            this.panel10.Controls.Add(this.textBox33);
            this.panel10.Controls.Add(this.pictureBox10);
            this.panel10.Location = new System.Drawing.Point(251, 309);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(242, 300);
            this.panel10.TabIndex = 5;
            // 
            // textGora6Kor
            // 
            this.textGora6Kor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.textGora6Kor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textGora6Kor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora6Kor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textGora6Kor.Location = new System.Drawing.Point(168, 1);
            this.textGora6Kor.Multiline = true;
            this.textGora6Kor.Name = "textGora6Kor";
            this.textGora6Kor.ReadOnly = true;
            this.textGora6Kor.Size = new System.Drawing.Size(74, 39);
            this.textGora6Kor.TabIndex = 3;
            // 
            // textGora6Alp
            // 
            this.textGora6Alp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.textGora6Alp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textGora6Alp.Enabled = false;
            this.textGora6Alp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora6Alp.Location = new System.Drawing.Point(3, 270);
            this.textGora6Alp.Multiline = true;
            this.textGora6Alp.Name = "textGora6Alp";
            this.textGora6Alp.Size = new System.Drawing.Size(175, 27);
            this.textGora6Alp.TabIndex = 4;
            // 
            // Gora6text
            // 
            this.Gora6text.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.Gora6text.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Gora6text.Enabled = false;
            this.Gora6text.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Gora6text.Location = new System.Drawing.Point(-1, 241);
            this.Gora6text.Multiline = true;
            this.Gora6text.Name = "Gora6text";
            this.Gora6text.Size = new System.Drawing.Size(243, 26);
            this.Gora6text.TabIndex = 2;
            // 
            // textBox33
            // 
            this.textBox33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.textBox33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox33.Enabled = false;
            this.textBox33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox33.Location = new System.Drawing.Point(-1, 208);
            this.textBox33.Multiline = true;
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(243, 27);
            this.textBox33.TabIndex = 1;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::The_Mountain_Project.Properties.Resources.Чо_Ойю;
            this.pictureBox10.Location = new System.Drawing.Point(0, 0);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(242, 202);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 0;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel7.Controls.Add(this.textGora7Kor);
            this.panel7.Controls.Add(this.textGora7Alp);
            this.panel7.Controls.Add(this.Gora7text);
            this.panel7.Controls.Add(this.textBox21);
            this.panel7.Controls.Add(this.pictureBox7);
            this.panel7.Location = new System.Drawing.Point(499, 309);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(242, 300);
            this.panel7.TabIndex = 9;
            // 
            // textGora7Kor
            // 
            this.textGora7Kor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.textGora7Kor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textGora7Kor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora7Kor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textGora7Kor.Location = new System.Drawing.Point(168, 1);
            this.textGora7Kor.Multiline = true;
            this.textGora7Kor.Name = "textGora7Kor";
            this.textGora7Kor.ReadOnly = true;
            this.textGora7Kor.Size = new System.Drawing.Size(74, 39);
            this.textGora7Kor.TabIndex = 3;
            // 
            // textGora7Alp
            // 
            this.textGora7Alp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.textGora7Alp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textGora7Alp.Enabled = false;
            this.textGora7Alp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora7Alp.Location = new System.Drawing.Point(3, 270);
            this.textGora7Alp.Multiline = true;
            this.textGora7Alp.Name = "textGora7Alp";
            this.textGora7Alp.Size = new System.Drawing.Size(175, 27);
            this.textGora7Alp.TabIndex = 4;
            // 
            // Gora7text
            // 
            this.Gora7text.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.Gora7text.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Gora7text.Enabled = false;
            this.Gora7text.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Gora7text.Location = new System.Drawing.Point(-1, 241);
            this.Gora7text.Multiline = true;
            this.Gora7text.Name = "Gora7text";
            this.Gora7text.Size = new System.Drawing.Size(243, 26);
            this.Gora7text.TabIndex = 2;
            // 
            // textBox21
            // 
            this.textBox21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.textBox21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox21.Enabled = false;
            this.textBox21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox21.Location = new System.Drawing.Point(-1, 208);
            this.textBox21.Multiline = true;
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(243, 27);
            this.textBox21.TabIndex = 1;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::The_Mountain_Project.Properties.Resources.Дхаулагири;
            this.pictureBox7.Location = new System.Drawing.Point(0, 0);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(242, 202);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel8.Controls.Add(this.textGora8Kor);
            this.panel8.Controls.Add(this.textGora8Alp);
            this.panel8.Controls.Add(this.Gora8text);
            this.panel8.Controls.Add(this.textBox25);
            this.panel8.Controls.Add(this.pictureBox8);
            this.panel8.Location = new System.Drawing.Point(747, 309);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(242, 300);
            this.panel8.TabIndex = 10;
            // 
            // textGora8Kor
            // 
            this.textGora8Kor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.textGora8Kor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textGora8Kor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora8Kor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textGora8Kor.Location = new System.Drawing.Point(168, 1);
            this.textGora8Kor.Multiline = true;
            this.textGora8Kor.Name = "textGora8Kor";
            this.textGora8Kor.ReadOnly = true;
            this.textGora8Kor.Size = new System.Drawing.Size(74, 39);
            this.textGora8Kor.TabIndex = 3;
            // 
            // textGora8Alp
            // 
            this.textGora8Alp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.textGora8Alp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textGora8Alp.Enabled = false;
            this.textGora8Alp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora8Alp.Location = new System.Drawing.Point(3, 270);
            this.textGora8Alp.Multiline = true;
            this.textGora8Alp.Name = "textGora8Alp";
            this.textGora8Alp.Size = new System.Drawing.Size(175, 27);
            this.textGora8Alp.TabIndex = 4;
            // 
            // Gora8text
            // 
            this.Gora8text.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.Gora8text.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Gora8text.Enabled = false;
            this.Gora8text.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Gora8text.Location = new System.Drawing.Point(-1, 241);
            this.Gora8text.Multiline = true;
            this.Gora8text.Name = "Gora8text";
            this.Gora8text.Size = new System.Drawing.Size(243, 26);
            this.Gora8text.TabIndex = 2;
            // 
            // textBox25
            // 
            this.textBox25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.textBox25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox25.Enabled = false;
            this.textBox25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox25.Location = new System.Drawing.Point(-1, 208);
            this.textBox25.Multiline = true;
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(243, 27);
            this.textBox25.TabIndex = 1;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::The_Mountain_Project.Properties.Resources.Манаслу;
            this.pictureBox8.Location = new System.Drawing.Point(0, 0);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(242, 202);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel9.Controls.Add(this.textGora9Kor);
            this.panel9.Controls.Add(this.textGora9Alp);
            this.panel9.Controls.Add(this.Gora9text);
            this.panel9.Controls.Add(this.textBox29);
            this.panel9.Controls.Add(this.pictureBox9);
            this.panel9.Location = new System.Drawing.Point(3, 615);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(242, 300);
            this.panel9.TabIndex = 11;
            // 
            // textGora9Kor
            // 
            this.textGora9Kor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.textGora9Kor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textGora9Kor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora9Kor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textGora9Kor.Location = new System.Drawing.Point(168, 1);
            this.textGora9Kor.Multiline = true;
            this.textGora9Kor.Name = "textGora9Kor";
            this.textGora9Kor.ReadOnly = true;
            this.textGora9Kor.Size = new System.Drawing.Size(74, 39);
            this.textGora9Kor.TabIndex = 3;
            // 
            // textGora9Alp
            // 
            this.textGora9Alp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.textGora9Alp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textGora9Alp.Enabled = false;
            this.textGora9Alp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora9Alp.Location = new System.Drawing.Point(3, 270);
            this.textGora9Alp.Multiline = true;
            this.textGora9Alp.Name = "textGora9Alp";
            this.textGora9Alp.Size = new System.Drawing.Size(175, 27);
            this.textGora9Alp.TabIndex = 4;
            // 
            // Gora9text
            // 
            this.Gora9text.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.Gora9text.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Gora9text.Enabled = false;
            this.Gora9text.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Gora9text.Location = new System.Drawing.Point(0, 241);
            this.Gora9text.Multiline = true;
            this.Gora9text.Name = "Gora9text";
            this.Gora9text.Size = new System.Drawing.Size(246, 26);
            this.Gora9text.TabIndex = 2;
            // 
            // textBox29
            // 
            this.textBox29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.textBox29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox29.Enabled = false;
            this.textBox29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox29.Location = new System.Drawing.Point(0, 208);
            this.textBox29.Multiline = true;
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(246, 27);
            this.textBox29.TabIndex = 1;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::The_Mountain_Project.Properties.Resources.Нангапарбат;
            this.pictureBox9.Location = new System.Drawing.Point(0, 0);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(242, 202);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel11.Controls.Add(this.textGora10Kor);
            this.panel11.Controls.Add(this.textGora10Alp);
            this.panel11.Controls.Add(this.Gora10text);
            this.panel11.Controls.Add(this.textBox37);
            this.panel11.Controls.Add(this.pictureBox11);
            this.panel11.Location = new System.Drawing.Point(251, 615);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(242, 300);
            this.panel11.TabIndex = 12;
            // 
            // textGora10Kor
            // 
            this.textGora10Kor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.textGora10Kor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textGora10Kor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora10Kor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textGora10Kor.Location = new System.Drawing.Point(168, 1);
            this.textGora10Kor.Multiline = true;
            this.textGora10Kor.Name = "textGora10Kor";
            this.textGora10Kor.ReadOnly = true;
            this.textGora10Kor.Size = new System.Drawing.Size(74, 39);
            this.textGora10Kor.TabIndex = 3;
            // 
            // textGora10Alp
            // 
            this.textGora10Alp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.textGora10Alp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textGora10Alp.Enabled = false;
            this.textGora10Alp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textGora10Alp.Location = new System.Drawing.Point(3, 270);
            this.textGora10Alp.Multiline = true;
            this.textGora10Alp.Name = "textGora10Alp";
            this.textGora10Alp.Size = new System.Drawing.Size(175, 27);
            this.textGora10Alp.TabIndex = 4;
            // 
            // Gora10text
            // 
            this.Gora10text.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(24)))), ((int)(((byte)(24)))));
            this.Gora10text.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Gora10text.Enabled = false;
            this.Gora10text.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Gora10text.Location = new System.Drawing.Point(-1, 241);
            this.Gora10text.Multiline = true;
            this.Gora10text.Name = "Gora10text";
            this.Gora10text.Size = new System.Drawing.Size(243, 26);
            this.Gora10text.TabIndex = 2;
            // 
            // textBox37
            // 
            this.textBox37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.textBox37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox37.Enabled = false;
            this.textBox37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox37.Location = new System.Drawing.Point(-1, 208);
            this.textBox37.Multiline = true;
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(243, 27);
            this.textBox37.TabIndex = 1;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::The_Mountain_Project.Properties.Resources.Аннапурна;
            this.pictureBox11.Location = new System.Drawing.Point(0, 0);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(242, 202);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 0;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.ForeColor = System.Drawing.Color.DarkGray;
            this.checkBox2.Location = new System.Drawing.Point(1100, 77);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(64, 17);
            this.checkBox2.TabIndex = 3;
            this.checkBox2.Text = "Высота";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.ForeColor = System.Drawing.Color.DarkGray;
            this.checkBox3.Location = new System.Drawing.Point(1100, 100);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(70, 17);
            this.checkBox3.TabIndex = 4;
            this.checkBox3.Text = "Материк";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.ForeColor = System.Drawing.Color.DarkGray;
            this.checkBox1.Location = new System.Drawing.Point(1100, 54);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(76, 17);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "Название";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.ForeColor = System.Drawing.Color.DarkGray;
            this.checkBox4.Location = new System.Drawing.Point(1100, 123);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(95, 17);
            this.checkBox4.TabIndex = 5;
            this.checkBox4.Text = "Год открытия";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(1100, 146);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Фильтр";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Location = new System.Drawing.Point(68, 3);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(1127, 543);
            this.panel12.TabIndex = 1;
            // 
            // bunifuElipse2
            // 
            this.bunifuElipse2.ElipseRadius = 5;
            this.bunifuElipse2.TargetControl = this;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(26)))), ((int)(((byte)(26)))));
            this.ClientSize = new System.Drawing.Size(1192, 590);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.Gora1.ResumeLayout(false);
            this.Gora1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.Panel Gora1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Button button1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton2;
        private System.Windows.Forms.TextBox Gora1text;
        private System.Windows.Forms.TextBox textGora1Kor;
        private System.Windows.Forms.TextBox textGora1Alp;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textGora2Alp;
        private System.Windows.Forms.TextBox textGora2Kor;
        private System.Windows.Forms.TextBox Gora2text;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox textGora3Alp;
        private System.Windows.Forms.TextBox textGora3Kor;
        private System.Windows.Forms.TextBox Gora3text;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textGora4Alp;
        private System.Windows.Forms.TextBox textGora4Kor;
        private System.Windows.Forms.TextBox Gora4text;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox textGora5Alp;
        private System.Windows.Forms.TextBox textGora5Kor;
        private System.Windows.Forms.TextBox Gora5text;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox textGora6Alp;
        private System.Windows.Forms.TextBox textGora6Kor;
        private System.Windows.Forms.TextBox Gora6text;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textGora7Alp;
        private System.Windows.Forms.TextBox textGora7Kor;
        private System.Windows.Forms.TextBox Gora7text;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox textGora8Alp;
        private System.Windows.Forms.TextBox textGora8Kor;
        private System.Windows.Forms.TextBox Gora8text;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox textGora9Alp;
        private System.Windows.Forms.TextBox textGora9Kor;
        private System.Windows.Forms.TextBox Gora9text;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox textGora10Alp;
        private System.Windows.Forms.TextBox textGora10Kor;
        private System.Windows.Forms.TextBox Gora10text;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Panel panel12;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse2;
    }
}